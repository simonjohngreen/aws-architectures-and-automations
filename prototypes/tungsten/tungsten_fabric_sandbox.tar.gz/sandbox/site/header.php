<table align="center">
  <tr>
    <th width="33%">&nbsp;</th><th align="center">Carbide Evaluation System</th><th width="33%" align="right"><img src='tungsten-fabric-300x184.png' width="40%"></th>
  </tr>
</table>